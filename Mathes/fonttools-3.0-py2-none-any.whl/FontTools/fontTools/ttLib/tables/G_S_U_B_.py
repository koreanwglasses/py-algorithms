from __future__ import print_function, division, absolute_import
from fontTools.misc.py23 import *
from .otBase import BaseTTXConverter


class table_G_S_U_B_(BaseTTXConverter):
	pass
