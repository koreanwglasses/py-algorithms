from __future__ import print_function, division, absolute_import
from fontTools.misc.py23 import *

version = "3.0"
